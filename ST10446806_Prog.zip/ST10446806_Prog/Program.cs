﻿using System;
using System.Speech.Synthesis;
using System.Media;
using System.Linq;


class Chatbot
{
    public string Name { get; set; }

    public Chatbot(string name)
    {
        Name = name;
    }

    public void GreetUser()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Hello! Welcome to " + Name + ". Your friendly Cybersecurity Awarenesss chatbot! Here to keep you safe online");
        Console.ResetColor();

    }

    public void Sound()
    {
        string filePath = @"E:\Projects\ST10446806_Prog\ProgAudio.wav";
        try
        {
            using (SoundPlayer player = new SoundPlayer(filePath))
            {
                player.PlaySync();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error playing sound: " + ex.Message);
        }





    }
    public void DisplayASCIIArt()
    {
        Task.Run(() => Sound());
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine(@"
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~   
  ██████╗ ██╗     ██╗   ██╗██████╗  ██████╗ ████████╗
  ██╔══██╗██║     ██║   ██║██╔══██╗██╔═══██╗╚══██╔══╝
  ██████╔╝██║     ██║   ██║██████╔╝██║   ██║   ██║   
  ██║  ██╗██║     ██║   ██║██╔══██╗██║   ██║   ██║   
  ██████╔╝███████╗╚██████╔╝██████╔╝╚██████╔╝   ██║   
  ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝  
                                                           
   ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗ 
   ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝
   ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗  
   ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝  
   ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗     
   ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝ 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

| Password Safety...
| Phishing...
| Data Secured...
| Threat Detection...");

        Console.ResetColor();
        Thread.Sleep(8500);
        Console.Clear();
    }


    public void Chat()
    {

        Console.WriteLine("What's your name? ");
        string userName = Console.ReadLine();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Nice to meet you, " + userName);
        Console.ResetColor();

        while (true)
        {
            Console.WriteLine("Feel free to ask me anything about Cyber Security");

            // Allows for a match even if user uses capitalization
            string userInput = Console.ReadLine().ToLower(); // Converts the input to lowercase

            string question = "what can i ask you about";

            if (userInput.Contains(question) || userInput.Contains("what can i ask you"))
            {
                Console.WriteLine("\nYou can ask anything about cybersecurity. Some examples are:");
                Console.WriteLine("- What's my purpose?");
                Console.WriteLine("- Password safety");
                Console.WriteLine("- What is phishing?");
                Console.WriteLine("- Safe browsing");

                while (true)
                {
                    Console.WriteLine("\nEnter your question (or type 'exit' to quit):");

                    Console.ForegroundColor = ConsoleColor.Gray;
                    string answer = Console.ReadLine().ToLower().Trim();
                    Console.ResetColor();

                    // Exit the loop if the user types 'exit'
                    if (answer.Contains("exit"))
                    {
                        Console.WriteLine("Goodbye! Stay safe online.");
                        return; // Exit the program completely
                    }

                    // Respond to specific questions about purpose
                    if (answer.Contains("what is my purpose")
                        || answer.Contains("what is your purpose")
                        || answer.Contains("what's my purpose")
                        || answer.Contains("what's your purpose")
                        || answer.Contains("whats my purpose")
                        || answer.Contains("whats your purpose"))
                    {
                        Console.WriteLine("My purpose is to provide knowledge on cybersecurity and its practices among users, such as employees, students, and organizations. I inform users of online threats and how to avoid these common risks, by sending notifications about potential threats and alerting users to risky activities.");
                        Console.WriteLine("If you would like to know more in-depth, don't be afraid to ask more questions.");
                    }
                    // Respond to questions about password safety
                    else if (answer.Contains("password safety"))
                    {
                        Console.WriteLine("Password safety helps protect your data and account from any intruders or attackers, and limits the possiblity of you account getting hacked");
                        Console.WriteLine("Other Questions asked:");
                        Console.WriteLine("Types of password practices");
                        Console.WriteLine("What makes a Strong password");
                        Console.WriteLine("Reusing Passwords");
                    }

                    // Respond to questions about phishing
                    else if (answer.Contains("phishing"))
                    {
                        Console.WriteLine("Phishing is a cyber attack, It is used by impersonating as an orginiazation,services or individuals to decieve users and gain sensitive information, " +
                            "examples are:" +
                            "Email - Links or downloads are sent via email, with the attacker disguised as a legitemate company, pressing on these links can cause you to be redirected to risky websites or have malicious malware installed on ur device" +
                            "Smishing - SMS phishing where malisious links and websites are sent via text messages");

                    }
                    // Respond to questions about safe browsing
                    else if (answer.Contains("safe browsing"))
                    {
                        Console.WriteLine("Safe browsing means the practices you follow to away from the risks of malicious websites, threats, viruses, identity theft and scams when browsing online");
                        SafeBrowsing();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("\nI'm not sure how to answer that. Could you try rephrasing? Or type 'exit' to quit.");
                        Console.ResetColor();
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("\nI'm not sure how to answer that. Could you try rephrasing? Or type 'exit' to quit.");
                Console.ResetColor();
            }
        }
    }

    public void SafeBrowsing() {
        Console.WriteLine("Futher Questions asked: How to Practice Safe Browsing");
        Console.WriteLine("What is a VPN");
        String answer = Console.ReadLine().ToLower();

        if (answer.Contains("How to Practice Safe Browsing") ||
            answer.Contains("Practice Safe Browsing")||
            answer.Contains("Safe Browsing Practices"))
        {
            Console.WriteLine("3 ways to practice Safe browsing");
            Console.WriteLine("Install an AD Blockers. Ad Blockers block unwanted ads on a website. Some ads can have malicious redirections to unsafe areas of the internet");
            Console.WriteLine("Use anti-virus, it protects you from malicious website in real time, which detect and blocks files and browsers that are harmful");
            Console.WriteLine("Do not use public wifi to access banking details or any sensitive information, because public internet is usaully not secure. This making it easier for hackers to gain access to ur sensitive information");
        }
        else if (answer.Contains("VPN") ||
            answer.Contains("What is a VPN") ||
            answer.Contains("Whats a VPN"))
        {
            Console.WriteLine("A VPN creates a secure and encrypted connection to the internet using");
        }

    }


    class Program
    {
        static void Main()
        {
            Chatbot bot = new Chatbot("BluBot Secure");
            bot.GreetUser();
            bot.DisplayASCIIArt();
            bot.Chat();
            

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}

