﻿using System;
using System.Speech.Synthesis;
using System.Media;
using System.Linq;
using System.Security.Cryptography.X509Certificates;


class Chatbot
{
    public string Name { get; set; }
    public string userName { get; set; }

    public Chatbot(string name)
    {
        Name = name;
        
    }

    public void GreetUser()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Hello! Welcome to " + Name + ". Your friendly Cybersecurity Awarenesss chatbot! Here to keep you safe online");
        Console.ResetColor();

    }

    public void Sound()
    {
        string filePath = @"E:\Projects\ST10446806_Prog\ProgAudio.wav";
        try
        {
            using (SoundPlayer player = new SoundPlayer(filePath))
            {
                player.PlaySync();
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Error playing sound: " + ex.Message);
            Console.ResetColor();
        }





    }

    public void DisplayASCIIArt()
    {
        Thread.Sleep(500);
        Task.Run(() => Sound());
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine(@"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
 Thread.Sleep(500);

        Console.WriteLine(@"

                         ██████╗ ██╗     ██╗   ██╗██████╗  ██████╗ ████████╗");
        Thread.Sleep(500);
        Console.WriteLine(@"                         ██╔══██╗██║     ██║   ██║██╔══██╗██╔═══██╗╚══██╔══╝"); Thread.Sleep(500);
        Console.WriteLine(@"                         ██████╔╝██║     ██║   ██║██████╔╝██║   ██║   ██║   "); Thread.Sleep(200);
        Console.WriteLine(@"                         ██║  ██╗██║     ██║   ██║██╔══██╗██║   ██║   ██║   "); Thread.Sleep(200);
        Console.WriteLine(@"                         ██████╔╝███████╗╚██████╔╝██████╔╝╚██████╔╝   ██║  "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝  "); Thread.Sleep(200);
        Console.WriteLine(@"                                                                          
                         ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗ "); Thread.Sleep(500);
        Console.WriteLine(@"                         ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝"); Thread.Sleep(200);
        Console.WriteLine(@"                         ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗ "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝"); Thread.Sleep(200);
        Console.WriteLine(@"                         ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗  "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝ "); Thread.Sleep(200);
        Console.WriteLine(@"
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(@"
| Password Safety...
| Phishing...
| Data Secured...
| Threat Detection...");

        Console.ResetColor();
        Thread.Sleep(4000);
        Console.Clear();
    }



    public void Chat()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("BluBoT Secure");
        Console.WriteLine("===============================================================================================");
        Console.WriteLine("What is your name? ");
        Console.ResetColor();

        string userName;
        while (true)
        {
            userName = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userName) || userName.Length <= 2)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Username must be more than 2 letters. Please try again.");
                Console.ResetColor();
            }
            else
            {
                break;
            }
        }

        while (true) // Main interaction loop
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nNice to meet you, " + userName);
            Console.WriteLine("Things you can ask me:");
            Console.WriteLine("- How am I doing?");
            Console.WriteLine("- What can I ask you?");
            Console.ResetColor();

            string feelings = Console.ReadLine().ToLower();

            if (feelings.Contains("how are you"))
            {
                while (true)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nI am doing well. How are you doing, " + userName + "?");
                    Console.ResetColor();
                    string userfeel = Console.ReadLine().ToLower();

                    string[] keywords = { "i'm", "i", "am", "im", "good", "well", "happy", "amazing", "great", "splendid", "doing" };
                    string[] badkeywords = { "i'm", "i", "am", "im", "doing", "bad", "awful", "sad" };
                    bool containsKeywordG = keywords.Any(word => userfeel.Contains(word));
                    bool containsKeywordB = badkeywords.Any(word => userfeel.Contains(word));

                    if (containsKeywordG)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("\nI'm happy to hear that!");
                        Console.ResetColor();
                        break;
                    }
                    else if (containsKeywordB)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("\nI'm sorry to hear that.");
                        Console.WriteLine("\nFeel free to ask me anything about Cyber Security.");
                        Console.ResetColor();
                        Chatquestions(); // This stays in place
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("\nI'm sorry, I didn't quite get that. Can you rephrase your answer?");
                        Console.ResetColor();
                    }
                } break;
            }
            else if (feelings.Contains("ask"))
            {
                Chatquestions();
                break;
            }
            else if (string.IsNullOrEmpty(feelings))
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("\nPlease enter a valid answer.");
                Console.ResetColor();
            }
            else
            {
                invalid();
            }
        }
    }

    public void Chatquestions()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nYou can ask anything about cybersecurity. Some examples are:");
        Console.WriteLine("- What's my purpose?");
        Console.WriteLine("- Password safety");
        Console.WriteLine("- What is phishing?");
        Console.WriteLine("- Safe browsing");
        Console.ResetColor();
        securityQ();
    }


    public void securityQ()
    {
        while (true)
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nEnter your question (or type 'exit' to quit):");
            Console.ResetColor();

            ;
            string answer = Console.ReadLine().ToLower().Trim();
           

            // Exit the loop if the user types 'exit'
            if (answer.Contains("exit"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nGoodbye" + userName + "! Stay safe online.");
                Console.ResetColor();
                return; // Exit the program completely
            }

            //questions about purpose
            if (answer.Contains("purpose"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nMy purpose is to provide knowledge on cybersecurity and its practices among users, such as employees, students, and organizations. I inform users of online threats and how to avoid these common risks, by sending notifications about potential threats and alerting users to risky activities.");
                Console.WriteLine("If you would like to know more in-depth, don't be afraid to ask more questions.");
                Console.ResetColor();
            }
            // Respond to questions about password safety
            else if (answer.Contains("password safety"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPassword safety helps protect your data and account from any intruders or attackers, and limits the possiblity of you account getting hacked");
                Console.WriteLine("Other Questions asked:");
                Console.WriteLine("Types of password practices");
                Console.WriteLine("What makes a Strong password");
                Console.WriteLine("Reusing Passwords");
                Console.ResetColor();
                passwordQ();
            }

            // Respond to questions about phishing
            else if (answer.Contains("phishing"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPhishing is a cyber attack, It is used by impersonating as an orginiazation,services or individuals to decieve users and gain sensitive information");
                Console.WriteLine("examples are:");
                Console.WriteLine("Email - Links or downloads are sent via email, with the attacker disguised as a legitemate company, pressing on these links can cause you to be redirected to risky websites or have malicious malware installed on ur device");
                Console.WriteLine("Smishing - SMS phishing where malisious links and websites are sent via text messages");
                Console.ResetColor();
            }
            // Respond to questions about safe browsing
            else if (answer.Contains("safe browsing"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nSafe browsing is the practices you follow to away from the risks of malicious websites, threats, viruses, identity theft and scams when browsing online");
                Console.ResetColor(); 
                SafeBrowsing();
            }
            else
            {
                invalid();
            }
        }
    }

    public void passwordQ()
    {
        Console.ResetColor();
        string answer = Console.ReadLine()?.ToLower().Trim(); // Ensure input is not null and remove extra spaces

        if (string.IsNullOrEmpty(answer))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nBot: Please enter a valid question.");
            Console.ResetColor();
            return;
        }

        if (answer.Contains("practices"))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nPassword Practices");

            Console.WriteLine("Biometric Passwords: It uses Biological features to create passwords on your device, using biometric scanner that scans your unique features, to calculate the match percentage of your biometric password");
            Console.WriteLine(" Multi-Factor Authentication (MFA), is an authentication process that uses two ways to grant acess to personal information and accounts. An OTP and a Password, an otp is a one time code sent to the verified email or cell number.");
            Console.WriteLine("Srong passwords can be used to keep anyone from accessing ur sensitive information, because stronger passwords are harder to crack");
            Console.ResetColor();
        }
        else if (answer.Contains("strong"))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nYou can create a Strong password by:");
            Console.WriteLine("Including special characters or numbers e.g. @,!,?");
            Console.WriteLine("Using more Characters to create longer passwords");
            Console.WriteLine("Do not use personal information: Birthdays, Names, phone numbers");
            Console.ResetColor();
        }
        else if (answer.Contains("reusing")|| answer.Contains("re-using"))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nIt increases the risks of syberattacks, if a hacker steals a password from one website it has access to your other accounts and your password can be spread and bought over the dark web");
            Console.ResetColor();
        }
    }
    public void SafeBrowsing() {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nFuther Questions asked: ");
        Console.WriteLine("- How to Practice Safe Browsing");
        Console.WriteLine("- What is a VPN?");
        Console.ResetColor();
        string answer = Console.ReadLine()?.ToLower().Trim(); // Ensure input is not null and remove extra spaces

        if (string.IsNullOrEmpty(answer))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nBot: Please enter a valid question.");
            Console.ResetColor();
            return;
        }

        // Phrases to match exactly
        string[] phrases =
        {
            "how to practice safe browsing",
            "practice safe browsing",
            "safe browsing practices"
        };

        // Keywords to check if any are present
        string[] keywords = { "how", "to", "practice", "safe", "browsing" };

        // Check if input contains an exact phrase OR at least one keyword
        bool containsPhrase = phrases.Any(phrase => answer.Contains(phrase));
        bool containsKeyword = keywords.Any(word => answer.Contains(word));

        if (containsPhrase || containsKeyword)
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" 3 Ways to Practice Safe Browsing:");
           
            Console.WriteLine("\nInstall an Ad Blocker: Ad blockers prevent unwanted ads, some of which contain malicious redirects to unsafe websites.");
            Console.WriteLine("Use an Antivirus: An antivirus program protects you from malicious websites in real-time, detecting and blocking harmful files and browsers.");
            Console.WriteLine("Avoid Public Wi-Fi for Sensitive Transactions: Public Wi-Fi is usually not secure, making it easier for hackers to access your sensitive information.");
            Console.ResetColor();
        }
        else if (answer.Contains("vpn"))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nA VPN creates a secure and encrypted connection to the internet using");
            Console.ResetColor();
        }

    }

    public void invalid()
    {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("\nI'm not sure how to answer that. Could you try rephrasing? Or type 'exit' to quit.");
                Console.ResetColor();
    }

    class Program
    {
        static void Main()
        {  

            Chatbot bot = new Chatbot("BluBot Secure");
            bot.GreetUser();
            bot.DisplayASCIIArt();
            bot.Chat();
            

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}

