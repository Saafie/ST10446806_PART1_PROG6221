﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using CyberSecurityChatbot;
using POEPart3;

namespace BlubotSecure
{
    public partial class MainWindow : Window
    {
        private List<Reminder> reminders = new List<Reminder>();
        private List<TaskItem> tasks = new List<TaskItem>();
        private ActivityLog activityLogger = new ActivityLog();

        private bool waitingForReminder = false;
        private string lastTaskTitle = "";

        private Quiz quiz = new Quiz();
        private QuizQuestion currentQuestion;
        private bool inQuizMode = false;
        private int correctAnswersCount = 0;
        private int questionNumber = 1;

        private CommandHandler commandHandler;
        private CyberChatManager chatManager;

        public MainWindow()
        {
            InitializeComponent();

            // Initialize CommandHandler and pass in necessary callbacks
            commandHandler = new CommandHandler(AddToChatbot, DisplayUserMessage, RespondToInput);

            // Initialize CyberChatManager with AddToChatbot and commandHandler.HandleInput
            chatManager = new CyberChatManager(AddToChatbot, commandHandler.HandleInput);

            // Initial the commands to greet and the Blubot secure show ASCII art
            commandHandler.HandleInput("greet");
            commandHandler.HandleInput("ascii");

            AddToChatbot("BluBoT Secure initialized. What is your name?");
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UserInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;
            DisplayUserMessage($"You: {input}");

            if (input.ToLower() == "next")
            {
                AddToChatbot("You can:");
                AddToChatbot("- Add a task (e.g. 'add task: Buy groceries')\nShow tasks\nUpdate task (e.g. 'update task 2' or 'Fix title:New description')\nComplete task (e.g. 'complete task 1')\nShow reminders\nView activity log\nStart quiz\nAsk cybersecurity questions like 'What is phishing?' or 'Password tips'");

                UserInput.Clear();
                return;
            }

            // First let commandHandler try to handle input
            if (!commandHandler.HandleInput(input))
            {
                // If commandHandler did NOT handle input, try RespondToInput (tasks, quiz, reminders)
                RespondToInput(input);
            }

            UserInput.Clear();
        }


        private void UserInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                SendButton_Click(sender, e);
                e.Handled = true;
            }
        }

        public void RespondToInput(string input)
        {
            string lower = input.ToLower().Trim();

            // CommandHandler tries to handle first
            if (commandHandler.HandleInput(input))
                return;

            // Reminder input handling
            if (waitingForReminder)
            {
                DateTime reminderDate = ParseReminderDate(input);
                if (reminderDate > DateTime.Now)
                {
                    AddToChatbot($"Got it! I'll remind you on {reminderDate:yyyy-MM-dd}.");
                    var task = tasks.LastOrDefault(t => t.Title == lastTaskTitle);
                    if (task != null)
                        task.ReminderDate = reminderDate;
                    LogAction($"Reminder set for task '{lastTaskTitle}' on {reminderDate:yyyy-MM-dd}");
                    waitingForReminder = false;
                    lastTaskTitle = "";
                    return;
                }

                if (lower.Contains("no"))
                {
                    AddToChatbot("No reminder set.");
                    waitingForReminder = false;
                    lastTaskTitle = "";
                    return;
                }

                AddToChatbot("Sorry, I didn't catch a valid date. Try 'in 3 days' or 'on 2025-12-01'.");
                return;
            }

            // Quiz mode handles input
            if (inQuizMode)
            {
                HandleQuizInput(input);
                return;
            }

            // Task addition
            if (IsAddTaskCommand(input))
            {
                string taskContent = input.Substring(input.IndexOf("task") + 4).TrimStart(':').Trim();
                string title = taskContent;
                string description = "";

                if (taskContent.Contains(":"))
                {
                    var parts = taskContent.Split(new[] { ':' }, 2);
                    title = parts[0].Trim();
                    description = parts[1].Trim();
                }

                if (string.IsNullOrWhiteSpace(title))
                {
                    AddToChatbot("Task title cannot be empty. Please provide a valid task title.");
                    return;
                }

                // Auto-generate description if user didn’t provide one
                if (string.IsNullOrWhiteSpace(description))
                {
                    description = chatManager.GetCybersecurityDescription(title);
                }


                tasks.Add(new TaskItem { Title = title, Description = description });
                AddToChatbot($"Task added: '{title}'{(description != "" ? $"\nDescription: {description}" : "")}");
                LogAction($"Task added: '{title}'");

                waitingForReminder = true;
                lastTaskTitle = title;
                AddToChatbot($"Would you like to set a reminder for '{title}'? Say something like 'in 3 days' or 'on 2025-12-01'.");
                return;
            }

            if (lower == "show reminders")
            {
                ShowReminders();
                return;
            }

            //checks input for log activity
            if (ContainsFuzzy(lower, "log") || ContainsFuzzy(lower, "activity") || ContainsFuzzy(lower, "done"))
            {
                if (!activityLogger.HasEntries())
                {
                    AddToChatbot("No recent activity.");
                }
                else
                {
                    AddToChatbot("📜 Here's a summary of recent actions:");
                    int count = 1;
                    foreach (string entry in activityLogger.GetRecentEntries())
                    {
                        AddToChatbot($"{count++}. {entry}");
                    }
                }

                var upcomingReminders = tasks
                    .Where(t => t.ReminderDate.HasValue && t.ReminderDate > DateTime.Now)
                    .OrderBy(t => t.ReminderDate)
                    .ToList();

                if (upcomingReminders.Any())
                {
                    AddToChatbot("\n🔔 Upcoming Reminders:");
                    foreach (var task in upcomingReminders)
                    {
                        AddToChatbot($"🔹 {task.Title} → {task.ReminderDate.Value:yyyy-MM-dd}");
                    }
                }
                return;
            }

            //checks all the valid inputs
            if (lower.Contains("quiz"))
            {
                StartQuiz();
                return;
            }

            if (StartsWith(lower, "add task") || IsAddTaskCommand(input))
            {
                UpdateTask(input);
                return;
            }

            if (StartsWith(lower, "update task") || lower.Contains("update") || lower.Contains("fix"))
            {
                UpdateTask(input);
                return;
            }

            if (StartsWith(lower, "complete task") || lower.Contains("complete"))
            {
                CompleteTask(input);
                return;
            }

            if (StartsWith(lower, "show tasks") || lower.Contains("show"))
            {
                ShowTasks();
                return;
            }
            
                AddToChatbot("Invalid Input. Please try commands like 'add task', 'show tasks', 'show reminders', or 'activity log'.");
                // Optionally fallback to chatbot conversation:
                chatManager.ReceiveInput(input);

        }

        private bool IsAddTaskCommand(string input)
        {
            string lower = input.ToLower();
            return lower.Contains("add task") || lower.StartsWith("add:") ||
                   lower.Contains("create a task") || lower.StartsWith("task:") ||
                   lower.StartsWith("please add task") || lower.StartsWith("add task:");
        }

        private void ShowReminders()
        { //shows the reminder dates and tasks
            if (reminders.Count == 0)
            {
                AddToChatbot("You have no upcoming reminders.");
                return;
            }

            AddToChatbot("Upcoming reminders:");
            foreach (var reminder in reminders.OrderBy(r => r.ReminderDate))
            {
                AddToChatbot($"🔔 '{reminder.TaskTitle}' on {reminder.ReminderDate:yyyy-MM-dd}");
            }
        }

        private DateTime ParseReminderDate(string input)
        {// allows for different date types to be captured
            string lower = input.ToLower();
            string[] formats = { "yyyy-MM-dd", "dd/MM/yyyy", "yyyy/MM/dd", "dd-MM-yyyy", "MM/dd/yyyy" };

            // converts into a date type
            if (lower.Contains("tomorrow")) return DateTime.Now.AddDays(1);
            if (lower.Contains("next week")) return DateTime.Now.AddDays(7);

            int daysFromNow = ExtractDaysFromText(lower);
            if (daysFromNow > 0) return DateTime.Now.AddDays(daysFromNow);

            foreach (string format in formats)
            {
                if (DateTime.TryParseExact(input, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime exact))
                    return exact;
            }

            foreach (string word in input.Split(' '))
            {
                foreach (string format in formats)
                {
                    if (DateTime.TryParseExact(word, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsed))
                        return parsed;
                }
                if (DateTime.TryParse(word, out DateTime fallback))
                    return fallback;
            }

            return DateTime.MinValue;
        }

        private int ExtractDaysFromText(string text)
        {
            var words = text.ToLower().Split(' ');
            for (int i = 0; i < words.Length - 1; i++)
            {// checks the valid inputs for date reminders
                if (words[i] == "in" && int.TryParse(words[i + 1], out int days))
                {
                    if (i + 2 < words.Length && (words[i + 2].StartsWith("day")))
                        return days;
                    return days;
                }
            }
            return -1;
        }

        private void StartQuiz()
        {// Start to the quiz
            quiz.Reset();
            correctAnswersCount = 0;
            currentQuestion = quiz.GetNextQuestion();
            inQuizMode = true;

            AddToChatbot("Quiz started! Answer by typing the letter of the correct option.");
            AddToChatbot($"🧠 Question {questionNumber}:\n{currentQuestion.GetFormattedQuestion()}");
            LogAction("Quiz started");
        }


        private void HandleQuizInput(string input)
        {// handles if the answers are correct or not
            if (currentQuestion.IsCorrect(input))
            {
                AddToChatbot("✅ Correct!");
                correctAnswersCount++;
            }
            else
            {
                AddToChatbot($"❌ Incorrect. The correct answer was: {currentQuestion.CorrectAnswer}");
            }
            // adds up the total of questions correct
            int totalAnswered = quiz.Questions.IndexOf(currentQuestion) + 1;
            AddToChatbot($"📊 Score so far: {correctAnswersCount}/{totalAnswered}");

            if (quiz.HasNextQuestion())
            {
                currentQuestion = quiz.GetNextQuestion();
                questionNumber++;
                AddToChatbot($"\n Question {questionNumber}:\n{currentQuestion.GetFormattedQuestion()}");
            }
            else
            {
                int total = quiz.Questions.Count;
                string message;

                //Output after the quiz is finished
                if (correctAnswersCount < 5)
                    message = $"You got {correctAnswersCount} out of {total}. You need to work on the material.";
                else if (correctAnswersCount < 8)
                    message = $"You got {correctAnswersCount} out of {total}. Good job, just need more practice.";
                else
                    message = $"You got {correctAnswersCount} out of {total}. Well done! You know a lot about cybersecurity.";

                AddToChatbot($"\n🎓 Final Score: {correctAnswersCount}/{total}");
                AddToChatbot($" Quiz finished! {message}");
                LogAction($"Quiz completed with score: {correctAnswersCount} out of {total}");

                inQuizMode = false;
                AddToChatbot("You can now continue with other commands.");
            }
        }



        private void DisplayUserMessage(string message)
        {
            AppendColoredText("\n", Colors.Black);
            AppendColoredText("Me: ", Colors.DarkGreen);
            AppendColoredText(message + "\n\n", Colors.Black);
        }

        private void AddToChatbot(string message)
        {
            AppendColoredText("BlueBot: ", Colors.Black);
            AppendColoredText(message + "\n\n", Colors.Black);

        }

        private void AppendColoredText(string text, Color color)
        {
            var paragraph = ChatOutput.Document.Blocks.LastBlock as Paragraph;
            if (paragraph == null)
            {
                paragraph = new Paragraph();
                ChatOutput.Document.Blocks.Add(paragraph);
            }
            Run run = new Run(text);
            run.Foreground = new SolidColorBrush(color);
            paragraph.Inlines.Add(run);
            ChatOutput.ScrollToEnd();
        }

        private void LogAction(string action)
        {
            activityLogger.Log(action);
        }

        private bool StartsWith(string input, string commandPhrase)
        {
            var inputWords = input.Split(' ');
            var commandWords = commandPhrase.Split(' ');
            if (inputWords.Length < commandWords.Length) return false;

            for (int i = 0; i < commandWords.Length; i++)
            {
                if (!IsCloseMatch(inputWords[i], commandWords[i])) return false;
            }
            return true;
        }

        private int Distance(string s, string t)
        {
            if (string.IsNullOrEmpty(s)) return t.Length;
            if (string.IsNullOrEmpty(t)) return s.Length;

            int[,] d = new int[s.Length + 1, t.Length + 1];

            for (int i = 0; i <= s.Length; i++) d[i, 0] = i;
            for (int j = 0; j <= t.Length; j++) d[0, j] = j;

            for (int i = 1; i <= s.Length; i++)
            {
                for (int j = 1; j <= t.Length; j++)
                {
                    int cost = (s[i - 1] == t[j - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(Math.Min(
                        d[i - 1, j] + 1,
                        d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }

            return d[s.Length, t.Length];
        }

        private void UpdateTask(string input)
        { // allows you to make changes to title and description
            string lower = input.ToLower();

            if (StartsWith(lower, "update task"))
            {
                string afterCommand = input.Substring(12).Trim();
                int firstSpace = afterCommand.IndexOf(' ');
                if (firstSpace == -1)
                {
                    AddToChatbot("Please provide the task number and new title/description.");
                    return;
                }

                string taskNumStr = afterCommand.Substring(0, firstSpace);
                string newContent = afterCommand.Substring(firstSpace + 1).Trim();

                if (!int.TryParse(taskNumStr, out int taskNum))
                {
                    AddToChatbot("Invalid task number. Please provide a valid number.");
                    return;
                }

                if (taskNum < 1 || taskNum > tasks.Count)
                {
                    AddToChatbot("The task number is out of range. Use 'show tasks' to see the list of tasks available.");
                    return;
                }

                string newTitle = newContent;
                string newDescription = "";

                if (newContent.Contains(":"))
                {
                    var parts = newContent.Split(new[] { ':' }, 2);
                    newTitle = parts[0].Trim();
                    newDescription = parts[1].Trim();
                }

                TaskItem task = tasks[taskNum - 1];
                task.Title = newTitle;
                task.Description = newDescription;

                if (string.IsNullOrWhiteSpace(newDescription))
                {
                    newDescription = chatManager.GetCybersecurityDescription(newTitle);
                }

                AddToChatbot($"✅ Task #{taskNum} updated:");
                AddToChatbot($"📝 Title: {newTitle}");
                AddToChatbot($"📌 Description: {newDescription}");

                LogAction($"Task updated: #{taskNum} → '{newTitle}'");

            }
        }

        private void CompleteTask(string input)
        {//allows you to show that you have completed a task
            string lower = input.ToLower();

            if (StartsWith(lower, "complete task"))
            {
                string numberPart = lower.Replace("complete task", "").Trim();

                if (int.TryParse(numberPart, out int taskNum))
                {
                    if (taskNum >= 1 && taskNum <= tasks.Count)
                    {
                        TaskItem task = tasks[taskNum - 1];

                        if (!task.Completed)
                        {
                            task.Completed = true;
                            AddToChatbot($"✅ Task '{task.Title}' marked as completed.");
                            LogAction($"Task completed: '{task.Title}'");
                        }
                        else
                        {
                            AddToChatbot($"Task '{task.Title}' is already completed.");
                        }
                    }
                    else
                    {
                        AddToChatbot("The task number is out of range. Use 'show tasks' to see the list of tasks available.");
                    }
                }
                else
                {
                    AddToChatbot("Format error. Try:\n 'complete task 2'");
                }
            }
        }

        private void ShowTasks()
        {// shows all tasks
            if (tasks.Count == 0)
            {
                AddToChatbot("There are no tasks found.");
                return;
            }

            AddToChatbot("📋 Your current tasks:");
            int count = 1;
            foreach (var task in tasks)
            {
                string status = task.Completed ? "✅ (Completed)" : "";
                string reminderInfo = task.ReminderDate.HasValue ? $"🔔 Reminder: {task.ReminderDate.Value:yyyy-MM-dd}" : "";

                AddToChatbot($"{count++}. {task.Title} {status} {reminderInfo}");

                if (!string.IsNullOrWhiteSpace(task.Description))
                {
                    AddToChatbot($"    📌 Description: {task.Description}");
                }
            }

        }
        



        private bool IsCloseMatch(string inputWord, string targetWord, int maxDistance = 1)
        {//allows for close similarity to a comparing word
            return Distance(inputWord.ToLower(), targetWord.ToLower()) <= maxDistance;
        }

        private bool ContainsFuzzy(string input, string keyword)
        {
            var words = input.Split(' ');
            foreach (var word in words)
            {
                if (IsCloseMatch(word, keyword))
                    return true;
            }
            return false;
        }
    }

    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public bool Completed { get; set; } = false;
        public DateTime? ReminderDate { get; set; }
    }
}


