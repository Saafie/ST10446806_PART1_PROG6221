﻿using System;
using System.Collections.Generic;
using System.Threading;
using testing_assignment_1;

public class CyberChatManager
{
    private Action<string> display;
    private string userName;
    private string userInterest = "";
    private string currentTopic = "";
    private readonly Func<string, bool> commandHandler;

    private enum ChatState
    {
        AskName,
        Greeting,
        TopicSelection,
        FollowUp,
        SafeBrowsingSubTopic
    }
    private ChatState currentState = ChatState.AskName;

    private Dictionary<string, Action> topicMap;

    private RandomResponses randomResponses = new RandomResponses();
    private ElaboratePhishing elaboratePhishing = new ElaboratePhishing();
    private PhishingInfo phishingInfo = new PhishingInfo();

    private SafeBrowsing safeBrowsing = new SafeBrowsing();
    private Password passwordHelper = new Password();

    private bool waitingForInterest = false;
    private bool waitingForFollowUp = false;

    public CyberChatManager(Action<string> displayMethod, Func<string, bool> commandHandlerMethod)
    {
        display = displayMethod;
        commandHandler = commandHandlerMethod;
        SetupTopics();
    }

    private void SetupTopics()
    {
        topicMap = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase)
        {
            { "phishing", ShowPhishing },
            { "password", passwordQ },
            { "safe browsing", SafeBrowsing },
            { "privacy", privacyTips },
            { "scam", ScamTips }
        };
    }


    private bool IsCloseMatch(string input, string keyword)
    {
        if (keyword.Length < 4)
            return input.Contains(keyword);

        return input.Contains(keyword.Substring(0, 4));
    }

    public void ReceiveInput(string input)
    {
        input = input.ToLower().Trim();

        if (string.IsNullOrWhiteSpace(input))
        {
            display("❗ Please enter a valid answer.");
            return;
        }

        if (input.Contains("exit"))
        {
            ExitChat();
            return;
        }

        // Handle SafeBrowsingSubTopic state first
        if (currentState == ChatState.SafeBrowsingSubTopic)
        {
            HandleSafeBrowsingInput(input);
            return;
        }

        // Waiting for user interest input
        if (waitingForInterest)
        {
            if (IsCloseMatch(input, "phishing") || IsCloseMatch(input, "privacy") || IsCloseMatch(input, "scam") || IsCloseMatch(input, "password") || IsCloseMatch(input, "safe browsing"))
            {
                if (input.Contains("phishing"))
                    userInterest = "phishing";
                else if (input.Contains("privacy"))
                    userInterest = "privacy";
                else if (input.Contains("scam"))
                    userInterest = "scam";
                else if (input.Contains("password"))
                    userInterest = "passwords";
                else if (input.Contains("safe browsing"))
                    userInterest = "safe browsing";

                display($"✅ Awesome! I'll remember you're interested in {userInterest}.");

                waitingForInterest = false;
                waitingForFollowUp = true;

                display("You can ask anything about cybersecurity. Some examples are: \n - " +
                "What's your purpose? \n" +
                "- Password safety \n" +
                "- What is phishing? \n" +
                "- Safe browsing\n" +
                "- Privacy\n" +
                "- Scams\n"+ "type Next: Add task, Update task, complete task, etc ");
            }
            else
            {
                display("❌ Sorry, I didn't recognize that interest. Please try one of: privacy, phishing, scam, passwords, or safe browsing.");
            }
            return;
        }

        // Waiting for follow up input
        if (waitingForFollowUp)
        {
            HandleFollowUp(input);
            return;
        }

        // **Here is the new integration: Try commandHandler first**
        if (commandHandler(input))
        {
            // If commandHandler handled the input, exit early
            return;
        }

        // Your existing switch case on currentState remains unchanged below

        switch (currentState)
        {
            case ChatState.AskName:
                if (input.Length <= 2)
                {
                    display("❗ Username must be more than 2 letters. Please try again.");
                }
                else
                {
                    userName = input;
                    display($"👋 Nice to meet you, {userName}!");
                    currentState = ChatState.Greeting;
                    ShowGreetingOptions();
                }
                break;

            case ChatState.Greeting:
                if (input.Contains("how") && input.Contains("you"))
                {
                    display($"😊 I’m doing well. How are you doing, {userName}?");
                    currentState = ChatState.TopicSelection;
                }
                else if (input.Contains("ask"))
                {
                    AskInterest();
                }
                break;

            case ChatState.TopicSelection:
                string sentiment = DetectSentiment(input);
                RespondWithEmpathy(sentiment);
                AskInterest();
                break;

            case ChatState.FollowUp:
                HandleFollowUp(input);
                break;

            default:
                break;
        }
    }


    private void HandleFollowUp(string input)
    {
        if (input.Contains("return"))
        {
            waitingForFollowUp = true;
            display("You can ask anything about cybersecurity. Some examples are: \n - What's your purpose? \n- Password safety \n- What is phishing? \n- Safe browsing\n- Privacy\n - Scams");
            return;
        }

        if (input.Contains("exit"))
        {
            ExitChat();
            return;
        }

        if (input.Contains("purpose"))
        {
            Thread.Sleep(200);
            display("\nMy purpose is to provide knowledge on cybersecurity and its practices among users, such as employees, students, and organizations. I inform users of online threats and how to avoid these common risks, by sending notifications about potential threats and alerting users to risky activities.");
            display("Exit: to Quit");
            return;
        }

        if (input.Contains("phishing"))
        {
            userInterest = "phishing";
            ShowPhishing();
            return;
        }

        if (input.Contains("reuse") || input.Contains("reusing") || input.Contains("reused"))
        {
            ShowReusingPasswordTip();
            return;
        }

        if (input.Contains("tip") || input.Contains("tips"))
        {
            ShowTips(userInterest);
            return;
        }

        if (input.Contains("more") || input.Contains("details"))
        {
            ShowDetails(userInterest);
            return;
        }

        if (input.Contains("password practice") || input.Contains("password practices"))
        {
            ShowPasswordPractice();
            return;
        }
        else if (input.Contains("strong"))
        {
            ShowStrongPasswordTips();
            return;
        }

        foreach (var topic in topicMap.Keys)
        {
            if (input.Contains(topic))
            {
                currentTopic = topic;
                topicMap[topic].Invoke();
                return;
            }
        }

        // Removed fallback message here
    }

    private void ShowPhishingInfo()
    {
        display("-------------------------------------------------------------------------------------------------------");
        display("\nPhishing is a cyber attack where attackers impersonate organizations, services, or individuals to deceive users and gain sensitive information.");
        display("Examples include:");
        display("Email - Links or downloads sent via email, with the attacker disguised as a legitimate company.");
        display("Clicking these links can redirect you to risky websites or install malware on your device.");
        display("Smishing - SMS phishing where malicious links and websites are sent via text messages.");
        display("Exit: to Quit");
        display("Return: Return to previous questions");
        display("-------------------------------------------------------------------------------------------------------");
    }

    private void ShowPhishing()
    {
        if (userInterest.Contains("phishing"))
        {
            ShowPhishingInfo();
            display($"🎣 Tip: {randomResponses.GetRandomPhishingTip()}");
            display($"🔍 Detail: {elaboratePhishing.GetRandomPhishingDetails()}");
            display("Ask for more tips, more details, 'return' to go back, or 'exit' to quit.");
        }
        else
        {
            display("No phishing interest found.");
        }
    }

    private void AskInterest()
    {
        waitingForInterest = true;
        waitingForFollowUp = false;
        currentState = ChatState.FollowUp;
        display($"\n🔎 Do you have a specific cybersecurity interest, {userName}? (phishing, scam, privacy, passwords, safe browsing)");
    }

    private void ShowPasswordPractice() => display(passwordHelper.passwordP());

    private void ShowStrongPasswordTips()
    {
        foreach (var line in passwordHelper.passwordS())
        {
            display(line);
        }
    }

    private void ShowReusingPasswordTip()
    {
        display("\nReusing passwords increases the risk of cyberattacks. If a hacker gets your password from one site, they could access other accounts too. Reused passwords are often sold on the dark web.");
        display("Return: Return to previous questions");
        display("Exit: to Quit");
    }

    private void ShowTips(string topic)
    {
        switch (topic)
        {
            case "phishing":
                display($"🎣 Phishing Tip: {randomResponses.GetRandomPhishingTip()}");
                break;
            case "privacy":
                display("🔐 Privacy Tip: Use strong passwords and enable two-factor authentication.");
                break;
            case "scam":
                display("💸 Scam Tip: Don't share personal information with unknown callers or emails.");
                break;
            case "passwords":
                display("🔑 Password Tip: Use a password manager to create and store strong passwords.");
                break;
            case "safe browsing":
                display("🌐 Safe Browsing Tip: Keep your browser updated and avoid suspicious websites.");
                break;
        }
    }

    private void ShowDetails(string topic)
    {
        switch (topic)
        {
            case "phishing":
                display($"🎣 Phishing Detail: {elaboratePhishing.GetRandomPhishingDetails()}");
                break;
            case "privacy":
                display("🔐 Privacy Details: Protect your privacy by controlling who can see your personal information online.");
                break;
            case "scam":
                display("💸 Scam Details: Scammers often impersonate trusted people or institutions to trick you.");
                break;
            case "passwords":
                display("🔑 Password Details: Strong passwords are long, random, and unique to each account.");
                break;
            case "safe browsing":
                display("🌐 Safe Browsing Details: Use HTTPS websites and consider using a VPN for better security.");
                break;
        }
    }

    private void ShowGreetingOptions()
    {
        display("🤖 You can ask me:");
        display("- How are you doing?");
        display("- What can I ask you?");
    }

    private string DetectSentiment(string input)
    {
        if (input.Contains("worried") || input.Contains("scared")) return "concerned";
        if (input.Contains("frustrated") || input.Contains("angry")) return "frustrated";
        if (input.Contains("curious") || input.Contains("interested")) return "curious";
        return "neutral";
    }

    private void RespondWithEmpathy(string sentiment)
    {
        switch (sentiment)
        {
            case "concerned":
                display("🫂 It's normal to feel concerned. Let's go over ways to stay safe online.");
                break;
            case "frustrated":
                display("😤 Cybersecurity can be tricky, but I’m here to help make it easier.");
                break;
            case "curious":
                display("🧠 Curiosity is great! Let’s dive deeper into your chosen topic.");
                break;
            default:
                display("💡 Let’s keep learning together! Ask anything.");
                break;
        }
    }

    private void ExitChat()
    {
        display($"👋 Goodbye {userName}! Stay safe online.");
    }

    private void passwordQ()
    {
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        if (userInterest.Contains("password"))
        {
            display("🔐 " + linkInterest.InterestG() + " passwords, " + eInterest.InterestExtra());
        }

        display("You can ask:");
        display("- What makes a strong password?");
        display("- Reusing passwords?");
        display("- Password practice");
    }

    private void privacyTips()
    {
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        if (userInterest.Contains("privacy"))
        {
            display("🔐 " + linkInterest.InterestG() + " privacy, " + eInterest.InterestExtra());
        }

        display("Tip: Avoid sharing personal details on public platforms. Use privacy settings on all apps.");
    }

    private void ScamTips()
    {
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        if (userInterest.Contains("scam"))
        {
            display("💸 " + linkInterest.InterestG() + " scams, " + eInterest.InterestExtra());
        }

        display("Tip: Always double-check strange messages asking for money or personal details.");
    }

    private void SafeBrowsing()
    {
        userInterest = "safe browsing";
        currentTopic = "safe browsing";

        display($"🌐 {safeBrowsing.GetDefinition()}");
        display("\nFurther Questions asked:");
        display("- How to Practice Safe Browsing");
        display("- What is a VPN?");
        display("Return: Return to previous questions");
        display("Exit: to Quit");
        display("-------------------------------------------------------------------------------------------------------");

        currentState = ChatState.SafeBrowsingSubTopic;
    }

    public string GetCybersecurityDescription(string topic)
    {// gets a description for the the task
        string lower = topic.ToLower();
        if (lower.Contains("phishing"))
            return "Phishing is a cyber attack that tricks you into revealing personal information via fake emails or websites.";
        if (lower.Contains("password"))
            return "Strong passwords protect your accounts. Use at least 12 characters, a mix of letters, numbers, and symbols.";
        if (lower.Contains("2fa") || lower.Contains("two factor"))
            return "2FA adds an extra layer of protection by requiring a second form of verification beyond a password.";
        if (lower.Contains("scam"))
            return "Scams are fraudulent schemes designed to steal your money or identity. Stay alert and verify sources.";
        if (lower.Contains("malware"))
            return "Malware is software designed to damage or gain unauthorized access to systems. Use antivirus and updates.";

        return "This task relates to cybersecurity. Stay informed and stay secure!";
    }


    private void HandleSafeBrowsingInput(string input)
    {
        if (input.Contains("return"))
        {
            currentState = ChatState.FollowUp;
            ReceiveInput(input);
            return;
        }

        if (input.Contains("safe"))
        {
            display(safeBrowsing.BrowsingPractices());
        }
        else if (input.Contains("vpn"))
        {
            display(safeBrowsing.VPN());
        }
        else if (input.Contains("exit"))
        {
            ExitChat();
        }
        else
        {
            // removed fallback message
        }
    }

    internal static string GetDescriptionFromKeyword(string title)
    {
        throw new NotImplementedException();
    }
}
