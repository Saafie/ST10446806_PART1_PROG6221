﻿using System;
using System.Collections.Generic;

namespace testing_assignment_1
{
    public class RandomResponses
    {
        private List<string> PhishingTips = new List<string>
        {
            "\nRecognize phishing signs. The attacker will send emails and messages that express urgency such as 'Your account will be closed' or 'You have 24 hours to change your password'.",
            "\nLook out for spelling and grammar mistakes in emails or messages.",
            "\nEmails or messages don't address you by your name; instead, they address you as 'Dear Customer'.",
            "\nDo not click on links or emails from unknown sources or suspicious email addresses. Verify the email by checking for misspellings, as official emails contain domain names such as @bank.com, instead of @gmail.com.",
            "\nProtect your information, never share your personal information such as passwords and credit cards via email. Enable (2FA) two-factor authentication to protect your account, as well as use strong passwords that are unique for different accounts."
        };

        public string GetRandomPhishingTip()
        {
            Random random = new Random();
            int index = random.Next(PhishingTips.Count);
            return PhishingTips[index];
        }
    }

    public class ElaboratePhishing
    {
        private List<string> PhishingDetails = new List<string>
        {
            "\nAttackers disguise themselves as trustworthy services such as banks and popular companies to steal your personal information using SMS, messages, emails, and phone calls.",
            "\nPhishing occurs when attackers research the victim, gathering information to create realistic messages that appear to come from a company or brand. They spoof emails and mimic professional communication.",
            "\nWith phishing, attackers send links or attachments that express urgency. These links may lead to fake login pages to steal your credentials, or attachments may download malware onto your device.",
            "\nIf you experience phishing, your personal information such as credentials may get stolen, malware installed, and financial fraud could occur."
        };

        public string GetRandomPhishingDetails()
        {
            Random random = new Random();
            int index = random.Next(PhishingDetails.Count);
            return PhishingDetails[index];
        }
    }

    public class PhishingInfo
    {
        public void PhishingIn()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\nPhishing is a cyber attack where attackers impersonate organizations, services, or individuals to deceive users and gain sensitive information.");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Examples include:");
            Console.WriteLine("Email - Links or downloads sent via email, with the attacker disguised as a legitimate company.");
            Console.WriteLine("Clicking these links can redirect you to risky websites or install malware on your device.");
            Console.WriteLine("Smishing - SMS phishing where malicious links and websites are sent via text messages.");

            Console.WriteLine("Exit: to Quit");
            Console.WriteLine("Return: Return to previous questions");
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        }
    }
}
