﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace POEPart3
{
    public class ActivityLog
    {
        private List<string> entries = new List<string>();

        public void Log(string message)
        {
            entries.Add($"{DateTime.Now:t} - {message}");

            if (entries.Count > 50)
                entries.RemoveAt(0);
        }

        public bool HasEntries()
        {
            return entries.Count > 0;
        }

        public List<string> GetRecentEntries(int count = 5)
        {
            return entries.Skip(Math.Max(0, entries.Count - count)).ToList();
        }
    }
}

