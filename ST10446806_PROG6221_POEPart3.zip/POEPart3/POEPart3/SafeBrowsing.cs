﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace testing_assignment_1
{
    public class SafeBrowsing
    {
        public string BrowsingPractices()
        {
            return

            "-------------------------------------------------------------------------------------------------------\n" +
            "3 Ways to Practice Safe Browsing:\n" +
            "\n1. Install an Ad Blocker: Ad blockers prevent unwanted ads, some of which contain malicious redirects to unsafe websites.\n" +
            "2. Use an Antivirus: An antivirus program protects you from malicious websites in real-time, detecting and blocking harmful files and browsers.\n" +
            "3. Avoid Public Wi-Fi for Sensitive Transactions: Public Wi-Fi is usually not secure, making it easier for hackers to access your sensitive information.\n" +
            "Return - Return to previous questions" +
            "Exit - To Quit" +
            "-------------------------------------------------------------------------------------------------------";

        }

        public string VPN()
        {
            return
            "------------------------------------------------------------------------------------------------------- \n" +
            "A VPN creates a secure and encrypted connection to the internet using a private network.\n" +
            "Return - Return to previous questions \n" +
            "Exit - To Quit \n" +
            "-------------------------------------------------------------------------------------------------------";
        }

        public string GetDefinition()
        {
            return "Safe browsing is the practices you follow to stay away from the risks of malicious websites, threats, viruses, identity theft, and scams when browsing online.";
        }

        public string GetFurtherQuestions()
        {
            return "\nFurther Questions asked:\n- How to Practice Safe Browsing\n- What is a VPN?\nReturn: Return to previous questions\nExit: to Quit\n-------------------------------------------------------------------------------------------------------";
        }
    }
}


