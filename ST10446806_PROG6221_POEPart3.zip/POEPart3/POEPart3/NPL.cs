﻿using System.Collections.Generic;

public class SimpleNLPProcessor
{
    public enum Intent
    {
        None,
        AddTask,
        UpdateTask,
        CompleteTask,
        ShowTasks,
        ShowLog,
        SetReminder,
        StartQuiz,
        AnswerQuiz,
        Unknown
    }

    public class NLPResult
    {
        public Intent DetectedIntent { get; set; } = Intent.None;
        public Dictionary<string, string> Entities { get; set; } = new Dictionary<string, string>();
    }

    public NLPResult Process(string input)
    {
        string lower = input.ToLower().Trim();
        var result = new NLPResult();

        if (lower.StartsWith("add task"))
        {
            result.DetectedIntent = Intent.AddTask;
            var content = input.Substring(8).Trim();
            var parts = content.Split(new[] { ':' }, 2);
            result.Entities["title"] = parts[0].Trim();
            if (parts.Length > 1) result.Entities["description"] = parts[1].Trim();
        }
        else if (lower.StartsWith("update task"))
        {
            result.DetectedIntent = Intent.UpdateTask;
            // format: update task <num> <new title>:<new desc>
            var after = input.Substring(11).Trim();
            var spaceIndex = after.IndexOf(' ');
            if (spaceIndex > 0)
            {
                result.Entities["taskNum"] = after.Substring(0, spaceIndex).Trim();
                var rest = after.Substring(spaceIndex + 1).Trim();
                var parts = rest.Split(new[] { ':' }, 2);
                result.Entities["newTitle"] = parts[0].Trim();
                if (parts.Length > 1) result.Entities["newDescription"] = parts[1].Trim();
            }
        }
        else if (lower.StartsWith("complete task"))
        {
            result.DetectedIntent = Intent.CompleteTask;
            var numberPart = input.Substring(13).Trim();
            result.Entities["taskNum"] = numberPart;
        }
        else if (lower.Contains("show tasks"))
        {
            result.DetectedIntent = Intent.ShowTasks;
        }
        else if (lower.Contains("log") || lower.Contains("activity"))
        {
            result.DetectedIntent = Intent.ShowLog;
        }
        else if (lower.Contains("remind me") || lower.Contains("reminder"))
        {
            result.DetectedIntent = Intent.SetReminder;
            result.Entities["reminderText"] = input;
        }
        else if (lower == "start quiz" || lower == "quiz")
        {
            result.DetectedIntent = Intent.StartQuiz;
        }
        else if (lower.Length == 1 && "abcd".Contains(lower))
        {
            result.DetectedIntent = Intent.AnswerQuiz;
            result.Entities["answer"] = lower;
        }
        else
        {
            result.DetectedIntent = Intent.Unknown;
        }

        return result;
    }
}
