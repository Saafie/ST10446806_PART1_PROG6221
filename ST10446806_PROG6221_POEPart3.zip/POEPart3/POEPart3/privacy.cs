﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing_assignment_1
{
    public class Privacy
    {
        private List<string> listPrivacy = new List<string> // extra details to phishing
      {"Avoid sharing personal information online, such as credit cards, posting birthdates or your location on social media. Disable location tracking and check privacy setting on all platforms.",
        "When browsing sensitive content, use incognito mode, regularly clear your history and clear cookies to reduce tracking. Use Firefox or brave that focuses on privacy, they also have privacy extensions.",
        "Revoke app access to files and information on your device. Reduce permissions to mics and install a VPN to hide your IP address.",
        "Enable authentication methods to protect your account privacy and use strong passwords."};
        public string listPrivacies()
        {
            Random random = new Random();
            int index = random.Next(listPrivacy.Count);
            return listPrivacy[index];
        }


    }

        public class Scam
    {
        private List<string> listScam = new List<string>
      {"Shopping scams, use trusted online shopping website, and ensure the websites contain 'https://'.  Try to avoid sellers who uses crypto and gift cards to sell products to you.",
        "Smishing, Avoid sending person personal information over SMS, when a person claims to be a trusted service such as a bank. banks do not ask for personal information over SMS.",
        "General Scam Protection, ensure to check bank statements regularly for any suspicious activity and report scams to banks and any relevant platforms and service." };

        public string listScams()
        {
            Random random = new Random();
            int index = random.Next(listScam.Count);
            return listScam[index];
        }
    } }
