﻿using System;
using System.IO;

namespace BlubotSecure
{
    public class CommandHandler
    {
        private readonly Action<string> addToChatbot;
        private readonly Action<string> display;
        private readonly Action<string> respond;

        public CommandHandler(Action<string> chatCallback, Action<string> displayMethod, Action<string> respondMethod)
        {
            addToChatbot = chatCallback;
            display = displayMethod;
            respond = respondMethod;
        }

        public bool HandleInput(string input)
        {
            string lower = input.ToLower();

            // Greeting / ASCII art
            if (lower.Contains("hello") || lower.Contains("greet"))
            {
                ShowGreeting();
                return true; // handled internally
            }
            else if (lower.Contains("ascii"))
            {
                ShowAsciiArt();
                return true; // handled internally
            }

            // the input its not handled internally, let caller handle it
            return false; // NOT handled here
        }

        private void ShowGreeting()
        {
            addToChatbot("👋 Hello! I’m BluBot Secure, your cybersecurity assistant.");
        }

        private void ShowAsciiArt()
        {
            string ascii = @"
                         ██████╗ ██╗     ██╗   ██╗██████╗  ██████╗ ████████╗  
                         ██╔══██╗██║     ██║   ██║██╔══██╗██╔═══██╗╚══██╔══╝
                         ██████╔╝██║     ██║   ██║██████╔╝██║   ██║   ██║   
                         ██║  ██╗██║     ██║   ██║██╔══██╗██║   ██║   ██║   
                         ██████╔╝███████╗╚██████╔╝██████╔╝╚██████╔╝   ██║  
                         ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝  
                                                                                  
                         ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗ 
                         ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝
                         ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗ 
                         ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝
                         ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗  
                          ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝ 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

| Password Safety... | Phishing... | Data Secured... | Threat Detection...
";
            addToChatbot(ascii);
            addToChatbot("What would you like to learn about today? 🤔");
            addToChatbot("Try topics like: passwords, phishing, scams, safe browsing, privacy...");
        }

        public void RedirectConsoleOutputToChat(Action action)
        {
            using (var stringWriter = new StringWriter())
            {
                var originalOut = Console.Out;
                Console.SetOut(stringWriter);

                action();

                Console.SetOut(originalOut);
                string output = stringWriter.ToString();
                addToChatbot(output.Trim());
            }
        }
    }
}
