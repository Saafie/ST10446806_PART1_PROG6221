﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POEPart3;

using System;

namespace POEPart3
{
    public class Reminder
    {
        public string TaskTitle { get; set; }
        public DateTime ReminderDate { get; set; }

        public override string ToString()
        {
            return $"Reminder for '{TaskTitle}' on {ReminderDate:yyyy-MM-dd}";
        }
    }
}

