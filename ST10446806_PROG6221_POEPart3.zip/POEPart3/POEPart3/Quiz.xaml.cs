﻿// Quiz.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberSecurityChatbot
{
    public class Quiz
    {
        private int currentQuestionIndex = 0;
        private List<QuizQuestion> allQuestions;
        public List<QuizQuestion> Questions { get; private set; }
        private Random random;

        public Quiz()
        {
            random = new Random();

            allQuestions = new List<QuizQuestion>
            {
                new QuizQuestion("What is a firewall used for?",
                    new[] { "A) To block unauthorized access", "B) To clean viruses", "C) To speed up internet", "D) To store passwords" }, "A"),

                new QuizQuestion("Which of these is a strong password practice?",
                    new[] { "A) Using your birthdate", "B) Using 'password123'", "C) Using a mix of letters, numbers, and symbols", "D) Using your pet's name" }, "C"),

                new QuizQuestion("What does VPN stand for?",
                    new[] { "A) Virtual Private Network", "B) Very Protected Network", "C) Verified Public Network", "D) Virtual Protected Node" }, "A"),

                new QuizQuestion("What should you NOT do when creating a password?",
                    new[] { "A) Use unique passwords for each account", "B) Share your password with friends", "C) Use a password manager", "D) Use long passwords" }, "B"),

                new QuizQuestion("What is phishing?",
                    new[] { "A) A way to catch fish", "B) Fraudulent attempts to obtain sensitive info", "C) A type of malware", "D) A network protocol" }, "B"),

                new QuizQuestion("Which is the safest way to connect to public Wi-Fi?",
                    new[] { "A) Use a VPN", "B) Connect without precautions", "C) Turn off your firewall", "D) Share files while connected" }, "A"),

                new QuizQuestion("What is multi-factor authentication?",
                    new[] { "A) Using only a password", "B) Using two or more methods to verify identity", "C) Using the same password everywhere", "D) Logging in from multiple devices" }, "B"),

                new QuizQuestion("What type of software protects your computer from viruses?",
                    new[] { "A) Antivirus", "B) Web browser", "C) Word processor", "D) Media player" }, "A"),

                new QuizQuestion("What should you do if you receive an unexpected attachment in an email?",
                    new[] { "A) Open it immediately", "B) Delete the email", "C) Scan the attachment before opening", "D) Forward it to others" }, "C"),

                new QuizQuestion("Which one of these is an example of social engineering?",
                    new[] { "A) Using a strong password", "B) Phishing emails", "C) Installing updates", "D) Using antivirus software" }, "B"),

                new QuizQuestion("What should you do if you receive an email asking for your password?",
                    new[] { "A) Reply with your password", "B) Delete the email", "C) Report the email as phishing", "D) Ignore it" }, "C"),

                new QuizQuestion("True or False: Using the same password for all your accounts is safe.",
                    new[] { "A) True", "B) False" }, "B"),

                new QuizQuestion("Which of the following is a strong password?",
                    new[] { "A) 123456", "B) password", "C) Q$7z!8fL", "D) abcdef" }, "C"),

                new QuizQuestion("What is phishing?",
                    new[] { "A) A cyberattack that tricks you into giving personal info", "B) A kind of fish", "C) Antivirus software", "D) None of the above" }, "A"),

                new QuizQuestion("Which one is safer?",
                    new[] { "A) HTTP", "B) HTTPS" }, "B"),

                new QuizQuestion("What does 2FA stand for?",
                    new[] { "A) Two-Factor Authentication", "B) Two-Firewall Access", "C) Two-Form Application", "D) None of these" }, "A"),

                new QuizQuestion("True or False: Public Wi-Fi is always safe to use without precautions.",
                    new[] { "A) True", "B) False" }, "B"),

                new QuizQuestion("Which of the following helps protect your computer from viruses?",
                    new[] { "A) VPN", "B) Antivirus software", "C) Passwords", "D) Cookies" }, "B"),

                new QuizQuestion("What should you check before clicking a link in an email?",
                    new[] { "A) The font", "B) The link destination", "C) The email color", "D) Nothing" }, "B"),

                new QuizQuestion("Which one is a form of social engineering?",
                    new[] { "A) Strong encryption", "B) Phishing email", "C) CAPTCHA", "D) Cloud storage" }, "B")
            };

            // Shuffle all questions and take first 10
            Questions = allQuestions.OrderBy(q => random.Next()).Take(10).ToList();
        }

        public void Reset()
        {
            currentQuestionIndex = 0;
        }

        public bool HasNextQuestion()
        {
            return currentQuestionIndex < Questions.Count;
        }

        public QuizQuestion GetNextQuestion()
        {
            if (HasNextQuestion())
                return Questions[currentQuestionIndex++];
            return null;
        }
    }

    public class QuizQuestion
    {
        public string Prompt { get; set; }
        public string[] Options { get; set; }
        public string CorrectAnswer { get; set; }

        public QuizQuestion(string prompt, string[] options, string correctAnswer)
        {
            Prompt = prompt;
            Options = options;
            CorrectAnswer = correctAnswer;
        }

        // Returns question plus options in a nicely formatted string
        public string GetFormattedQuestion()
        {
            return $"{Prompt}\n{string.Join("\n", Options)}";
        }

        public bool IsCorrect(string userAnswer)
        {
            return userAnswer.Trim().Equals(CorrectAnswer, StringComparison.OrdinalIgnoreCase);
        }
    }
}

