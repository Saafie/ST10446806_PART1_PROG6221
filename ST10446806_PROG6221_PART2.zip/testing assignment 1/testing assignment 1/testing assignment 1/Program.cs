﻿
using System;
using System.ComponentModel;
using System.Media;
using System.Threading;
using Microsoft.VisualBasic;
using testing_assignment_1;

class Chatbot
{
    private RandomResponses randomResponses;
    public string Interest { get; set; }
    public string Name { get; set; }
    public string userName { get; set; }

    // Memory & Context 
    private string currentTopic;
    private string userInterest;
    private string lastUserMessage;

    public Chatbot(string name, string username, string interest)
    {
        Name = name;
        userName = username;
        Interest = interest;
        currentTopic = "";
        userInterest = "";
        lastUserMessage = "";
        randomResponses = new RandomResponses();
    }

    public void GreetUser()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Hello! Welcome to " + Name + ". Your friendly Cybersecurity Awareness chatbot! Here to keep you safe online");
        Console.ResetColor();
    }

    public void Sound()
    {
        string filePath = @"C:\Users\Insaaf Behardien\source\repos\testing assignment 1\testing assignment 1\testing assignment 1\ProgAudio.wav";
        try
        {
            using (SoundPlayer player = new SoundPlayer(filePath))
            {
                player.PlaySync();
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Error playing sound: " + ex.Message);
            Console.ResetColor();
        }
    }

    public void DisplayASCIIArt()
    {// ASCIIART 
        Thread.Sleep(500);
        Task.Run(() => Sound());
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(@"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");


        Thread.Sleep(500);

        Console.WriteLine(@" 
 
                         ██████╗ ██╗     ██╗   ██╗██████╗  ██████╗ ████████╗");
        Thread.Sleep(500);
        Console.WriteLine(@"                         ██╔══██╗██║     ██║   ██║██╔══██╗██╔═══██╗╚══██╔══╝"); Thread.Sleep(500);
        Console.WriteLine(@"                         ██████╔╝██║     ██║   ██║██████╔╝██║   ██║   ██║   "); Thread.Sleep(200);
        Console.WriteLine(@"                         ██║  ██╗██║     ██║   ██║██╔══██╗██║   ██║   ██║   "); Thread.Sleep(200);
        Console.WriteLine(@"                         ██████╔╝███████╗╚██████╔╝██████╔╝╚██████╔╝   ██║  "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝  "); Thread.Sleep(200);
        Console.WriteLine(@"                                                                           
                         ███████╗███████╗ ██████╗██╗   ██╗██████╗ ███████╗ "); Thread.Sleep(500);
        Console.WriteLine(@"                         ██╔════╝██╔════╝██╔════╝██║   ██║██╔══██╗██╔════╝"); Thread.Sleep(200);
        Console.WriteLine(@"                         ███████╗█████╗  ██║     ██║   ██║██████╔╝█████╗ "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚════██║██╔══╝  ██║     ██║   ██║██╔══██╗██╔══╝"); Thread.Sleep(200);
        Console.WriteLine(@"                         ███████║███████╗╚██████╗╚██████╔╝██║  ██║███████╗  "); Thread.Sleep(200);
        Console.WriteLine(@"                         ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝ "); Thread.Sleep(200);
        Console.WriteLine(@" 
  

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        Console.ForegroundColor = ConsoleColor.Cyan; //Changes font color
        Console.WriteLine(@" | Password Safety... | Phishing... | Data Secured... | Threat Detection...");

        Console.ResetColor();
        Thread.Sleep(4000);
        Console.Clear();
    }



    public void Chat()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("BluBoT Secure");
        Console.WriteLine("===============================================================================================");
        Console.WriteLine("What is your name? ");
        Console.ResetColor();

        while (true)
        {
            userName = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userName) || userName.Length <= 2)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Username must be more than 2 letters. Please try again.");
                Console.ResetColor();
            }
            else
            {
                break;
            }
        }

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nNice to meet you, {userName}!");
            Console.WriteLine("***************************************************");
            Console.WriteLine("Things you can ask me:");
            Console.WriteLine("- How are you doing?");
            Console.WriteLine("- What can I ask you?");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ResetColor();

            string input = Console.ReadLine().ToLower();

            if (input.Contains("exit"))
            {
                ExitChat();
            }

            if (input.Contains("how") || input.Contains("are") || input.Contains("doing"))
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"\nI am doing well. How are you doing, {userName}?");
                Console.ResetColor();

                string userfeel = Console.ReadLine().ToLower();
                string sentiment = DetectSentiment(userfeel);
                RespondWithEmpathy(sentiment);

                AskInterest();
                Chatquestions();
                break;
            }
            else if (input.Contains("ask"))
            {
                AskInterest();
                Chatquestions();
                break;
            }
            else if (string.IsNullOrEmpty(input))
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("\nPlease enter a valid answer.");
                Console.ResetColor();
            }
            else
            {
                invalid();
            }
        }
    }

    private void AskInterest()
    {
        {
            while (true)
            {
                Console.WriteLine($"\nLet me ask you first. Do you have a specific area of cybersecurity you're interested in, {userName}? (e.g., privacy, phishing, scam, passwords)");
                string input = Console.ReadLine().ToLower();

                if (IsCloseMatch(input, "phishing"))
                {
                    userInterest = "phishing";
                    break;
                }
                else if (IsCloseMatch(input, "privacy"))
                {
                    userInterest = "privacy";
                    break;
                }
                else if (IsCloseMatch(input, "scam"))
                {
                    userInterest = "scam";
                    break;
                }
                else if (IsCloseMatch(input, "password"))
                {
                    userInterest = "passwords"; // normalize to plural 
                    break;
                }
                else
                {
                    Console.WriteLine("Sorry, I didn't recognize that interest. Please try one of: privacy, phishing, scam, or passwords.");
                    
                }
               
            }
            Console.WriteLine($"Awesome! I'll remember you're interested in {userInterest}."); //calls the userInterest that was stored
        }
    }
    

private bool IsCloseMatch(string input, string keyword)
    {
        // Acceptsmall typos
        return input.Contains(keyword.Substring(0, 4)); // e.g. "phish", "priv", "pass", "scam"
    }


    private string DetectSentiment(string input)
    {
        if (input.Contains("worried") || input.Contains("scared")) return "concerned";
        if (input.Contains("frustrated") || input.Contains("angry")) return "frustrated";
        if (input.Contains("curious") || input.Contains("interested")) return "curious";
        return "neutral";
    }

    private void RespondWithEmpathy(string sentiment)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        switch (sentiment)
        {
            case "concerned":
                Console.WriteLine("It's completely normal to feel concerned. Let's go over some tips to protect yourself online."); // expresses empathy for concern
                break;
            case "frustrated":
                Console.WriteLine("Cybersecurity can be frustrating, but don't worry I'm here to help give you tips to be safe online.");// expresses empathy for frustration
                break;
            case "curious":
                Console.WriteLine("Curiosity is influences learning! Let’s dive deeper into what you’re interested in.");// expresses empathy for curiosity
                break;
            default:
                Console.WriteLine("Let’s keep learning together. Feel free to ask any questions!");
                break;
        }
        Console.ResetColor();
    }
    public void Chatquestions()
    //method to get questions
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nYou can ask anything about cybersecurity. Some examples are:");
        Console.WriteLine("- What's your purpose?");
        Console.WriteLine("- Password safety");
        Console.WriteLine("- What is phishing?");
        Console.WriteLine("- Safe browsing");
        Console.WriteLine("- Privacy");
        Console.WriteLine("- Scams");
        Console.ResetColor();
        Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        securityQ();
    }

   

    public void securityQ()
{
    var topicMap = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase)
    {
        { "phishing", ShowPhishing },
        { "password", passwordQ },
        { "safe browsing", SafeBrowsing },
        { "privacy", privacyTips },
        { "scam", ScamTips }
    };

    while (true)
    {
        string answer = quit();

        bool matched = false;

        foreach (var entry in topicMap)
        {
            if (answer.Contains(entry.Key))
            {
                currentTopic = entry.Key; // for memory
                entry.Value.Invoke(); // Call the associated method
                matched = true;
                break;
            }
        }

        if (!matched)
        {
            if (answer.Contains("purpose"))
            {
                Thread.Sleep(200);
                Console.ForegroundColor = ConsoleColor.Blue;  
                Console.WriteLine("\nMy purpose is to provide knowledge on cybersecurity and its practices among users, such as employees, students, and organizations. I inform users of online threats and how to avoid these common risks, by sending notifications about potential threats and alerting users to risky activities.");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Exit: to Quit");
                Console.ResetColor();
                Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            }
            else
            {
                invalid();
            }
        }
    }
}

public void ShowPhishing()
    {

        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;

        //Creates an instance of a ElaboratePhishing class gives access to extra detailed phishing
        ElaboratePhishing elaboratePhishing = new ElaboratePhishing();
        //Creates an instance of a PhishingInfo class gives access to the general definition and examples of phishing
        PhishingInfo phishingInfo = new PhishingInfo();
        //Creates instance of Interest and InterestB to allow access to random interest recall
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        if (userInterest.Contains("phishing"))
        {
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(linkInterest.InterestG() + " phishing, " + eInterest.InterestExtra() + ". ") ;
            phishingInfo.PhishingIn();
            Console.ResetColor();
        }
        else
        {
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            phishingInfo.PhishingIn(); // / Brings out the method phishingIn. Displays gives definition and examples
            Console.ResetColor();

        }
        
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nWould you like a phishing tips or ask something else?");
            Console.WriteLine("Type 'tip','more details', 'return' or 'exit'"); // Ask if you want more tips, more details, or you want to retuen to previous questions, or exit console
            Console.ResetColor();
            string tips = Console.ReadLine().ToLower().Trim();

            if (tips.Contains("tip"))
            {
                ShowTip();
            }
            else if (tips.Contains("details") || tips.Contains("elaborate") || tips.Contains("more"))
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(elaboratePhishing.GetRandomPhishingDetails()); // Displays the random phishing details
                Console.ResetColor();
            }
            else if (tips == "return")
            {
                Chatquestions();
                break;
            }
            else if (tips == "exit")
            {
                ExitChat();
            }
            else
            {
                invalid();
            }
        }
    }


    public void privacyTips()
    {
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        Privacy privacyList = new Privacy();
        if (userInterest.Contains("privacy") || userInterest.Contains("privacies"))
        {// Brings out the method listPrivacies form privacy class
         // Brings out the method InterestExtra and InterestG from class Interest, InterestB
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(linkInterest.InterestG() + " privacy, " + eInterest.InterestExtra() + ". " + "\nPrivacy tip: "+ privacyList.listPrivacies());
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nPrivacy tip: " + privacyList.listPrivacies());// Brings out the method listPrivacies form privacy class
            Console.ResetColor();

        }

    }
    public void ScamTips()
    {
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        Scam scamList = new Scam();
        if (userInterest.Contains("scams") || userInterest.Contains("scam"))
        {// Brings out the method scam form privacy class
         // Brings out the method InterestExtra and InterestG from class Interest, InterestB
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(linkInterest.InterestG() + " Scams, " + eInterest.InterestExtra() + "\nPassword practice tip: " + scamList.listScams());
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nPassword practice tip: " + scamList.listScams());
            Console.ResetColor();

        }

    }

    public void ShowTip()
    {
        string userInput;

        do
        {
            string tip = randomResponses.GetRandomPhishingTip();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nPhishing Awareness Tip:");
            Console.WriteLine(tip);// brings the method out of call RandomResponses
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");

            Console.WriteLine("\nWould you like to see another phishing tip? (yes/no)");
            userInput = Console.ReadLine().ToLower();

            while (userInput != "yes" && userInput != "no")// leads to ask for more tips after 1 is given
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Please answer with 'yes' or 'no'.");
                Console.ResetColor();
                userInput = Console.ReadLine().ToLower();
            }

        } while (userInput == "yes");// If yes gives more random tips

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nNo problem! Let me know if you have other cybersecurity questions.");
        Console.ResetColor();
    }

    public void passwordQ()
    {//questions on password
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nPassword safety helps protect your data and account from any intruders or attackers, and limits the possibility of you account getting hacked");
        Console.WriteLine("- You can ask about:");
        Console.WriteLine("- Types of password practices");
        Console.WriteLine("- What makes a strong password");
        Console.WriteLine("- Reusing passwords");
        Console.WriteLine("Type 'Return' to go back or 'Exit' to quit.");
        Console.ResetColor();
        Console.WriteLine("-------------------------------------------------------------------------------------------------------");


        Password passwordInfo = new Password();
        Interest linkInterest = new Interest();
        InterestB eInterest = new InterestB();

        while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nWhat would you like to know about passwords?");
                Console.ResetColor();

                string answer = Console.ReadLine().ToLower().Trim();

            if (answer == "exit")
            {
                Environment.Exit(0);// exits the console
            }
            else if (answer == "return") //returns to previous questions of password
            {
                Chatquestions();
                break;
            }
            else if ( answer.Contains("practices") || answer.Contains("practice"))
            {
                if (userInterest.Contains("passwords") || userInterest.Contains("password"))
                {
                   
                    // Brings out the method password form Password class
                    // Brings out the method InterestExtra and InterestG from class Interest, InterestB
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(linkInterest.InterestG()+ " passwords, "+ eInterest.InterestExtra()+ ". "+ passwordInfo.passwordP());
                    Console.ResetColor();
                   
                }
                else
                {
                    
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nPassword practice tip: "+ passwordInfo.passwordP()); // Brings out the method password form class
                    Console.ResetColor();
                    

                }
            }
            else if (answer.Contains("strong"))
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                passwordInfo.passwordS();
            }
            else if (answer.Contains("reusing") || answer.Contains("re-using"))
            {//what reusing is
                Thread.Sleep(200);
                Console.WriteLine("-------------------------------------------------------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nReusing passwords increases the risk of cyberattacks. If a hacker gets your password from one site, they could access other accounts too. Reused passwords are often sold on the dark web.");
                Console.ResetColor();
                Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            }
            else
            {
                invalid(); // fallback for unexpected input
            }

                Console.ForegroundColor = ConsoleColor.Cyan; // gives examples of follow up questions
                Console.WriteLine("\nWould you like to ask about another password topic?");
                Console.WriteLine("You can say 'practices', 'strong', 'reusing', 'return' or 'exit'.");
                Console.ResetColor();
            }
        }
    





    //safe Browsing method 
    public void SafeBrowsing()
    {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Blue;
        //Definition of safe browsing
        Console.WriteLine("\nSafe browsing is the practices you follow to away from the risks of malicious websites, threats, viruses, identity theft and scams when browsing online");
        Console.ResetColor();
        Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;
        //allows for futher questions
        Console.WriteLine("\nFurther Questions asked: ");
        Console.WriteLine("- How to Practice Safe Browsing");
        Console.WriteLine("- What is a VPN?");
        Console.WriteLine("Return: Return to previous questions");
        Console.WriteLine("Exit: to Quit");
        Console.ResetColor();
        Console.WriteLine("-------------------------------------------------------------------------------------------------------");

        

        SafeBrowsing safeBrowsing = new SafeBrowsing();
        var topicMap = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase)
{
         { "safe", safeBrowsing.BrowsingPractices },
         { "vpn", safeBrowsing.VPN }
};

        while (true) // loop to keep the conversation going
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nWhat would you like to know more about? (e.g., safe browsing, VPN, return, exit)"); // gives you the questions to choose from
            Console.ResetColor();

            string userInput = Console.ReadLine().ToLower().Trim();

            if (userInput == "exit")
            {
                Environment.Exit(0); // Exits the program
            }
            else if (userInput == "return")
            {
                Chatquestions(); // Goes back to the previous menu
                break;
            }

            bool matched = false;

            foreach (var entry in topicMap)
            {
                if (userInput.Contains(entry.Key))
                {
                    currentTopic = entry.Key; // store memory
                    entry.Value.Invoke(); // Call associated method like VPN/Safe Browsing
                    matched = true;
                    break;
                }
            }

            if (!matched)
            {
                invalid(); // Deals with unknow inputs
            }

            // Loop will continue to allow for follow-up questions
        }
    }



    public void invalid() //Displays Error 
    {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine("\nI'm not sure how to answer that. Could you try rephrasing? Or type 'exit' to quit.");
        Console.ResetColor();
    }

    public string quit() // Quitting console method 
    {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nEnter your question form the list above:");
        Console.ResetColor();

        string answer = Console.ReadLine().ToLower().Trim();

        // Typing 'exit'. Exits the loop
        if (answer.Contains("exit"))
        {
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nGoodbye " + userName + "! Stay safe online.");
            Console.ResetColor();

            // Exit the application 
            Environment.Exit(0);
        }
        else if (string.IsNullOrEmpty(answer))
        {// Answer is null  shows invalid answer
            Thread.Sleep(200);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nBot: Please enter a valid question.");
            Console.ResetColor();
            return answer;
        }
        else if (answer.Contains("return"))
        {//Return to previous questions 
            Chatquestions();
            return "";
        }

        return answer; // Return the answer
    }


    public void ExitChat()
    {
        Thread.Sleep(200);
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\nGoodbye {userName}! Stay safe online.");
        Console.ResetColor();
        Environment.Exit(0);
    }
}

    class Program
    {
        static void Main()
        {

            Chatbot bot = new Chatbot("BluBot Secure","","");
            bot.GreetUser();
            bot.DisplayASCIIArt();
            bot.Chat();
           


            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }


