﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing_assignment_1
{
    public class SafeBrowsing
    {
        public void BrowsingPractices()
        {
            Thread.Sleep(200);
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("3 Ways to Practice Safe Browsing:");
            Console.WriteLine("\nInstall an Ad Blocker: Ad blockers prevent unwanted ads, some of which contain malicious redirects to unsafe websites.");
            Console.WriteLine("Use an Antivirus: An antivirus program protects you from malicious websites in real-time, detecting and blocking harmful files and browsers.");
            Console.WriteLine("Avoid Public Wi-Fi for Sensitive Transactions: Public Wi-Fi is usually not secure, making it easier for hackers to access your sensitive information.");
            Console.WriteLine("Return: Return to previous questions");
            Console.WriteLine("Exit: To Quit");
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        }

        public void VPN()
        {
            Thread.Sleep(200);
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nA VPN creates a secure and encrypted connection to the internet using a private network.");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Return: Return to previous questions");
            Console.WriteLine("Exit: To Quit");
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        }
    }
}
