﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing_assignment_1
{
    public class Password
    {

        private List<string> PasswordPractices = new List<string>
        {
            "\nBiometric Passwords: It uses Biological features to create passwords on your device, using biometric scanner that scans your unique features, to calculate the match percentage of your biometric password.",
            "\nMulti-Factor Authentication (MFA), is an authentication process that uses two ways to grant access to personal information and accounts. An OTP and a Password, an otp is a one time code sent to the verified email or cell number.",
            "\nStrong passwords can be used to keep anyone from accessing your sensitive information, because stronger passwords are harder to crack.",
            "\nProtect your information, never share your personal information such as passwords and credit cards via email. Enable (2FA) two-factor authentication to protect your account, as well as use strong passwords that are unique for different accounts."
        };



        public string passwordP() // method to passwords extra questions 
        {
            Random random = new Random();
            int index = random.Next(PasswordPractices.Count);
            return PasswordPractices[index];

        }

        public void passwordS()
        {
            Thread.Sleep(200);
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nYou can create a Strong password by:");
            Console.WriteLine("Including special characters or numbers e.g. @,!,?");
            Console.WriteLine("Using more Characters to create longer passwords");
            Console.WriteLine("Do not use personal information: Birthdays, Names, phone numbers");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Return: Return to previous questions");
            Console.WriteLine("Exit: to Quit");
            Console.ResetColor();

            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
        }


        
    }
}

