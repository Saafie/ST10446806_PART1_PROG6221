﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing_assignment_1
{
    public class Interest
    {


        private List<string> linkInterest = new List<string>
        {
            "\nAs someone who is interested in",
            "\nGiven that you are interested in",
            "\nYou mentioned you are interested in",
            "\nBased on your interest in"
        };

        public string InterestG() // method to passwords extra questions 
        {
            Random random = new Random();
            int index = random.Next(linkInterest.Count);
            return linkInterest[index];

        }
    }
 public class InterestB
    {
      private List<string> extraInterest = new List<string>
        {
            "you might find this very helpful.",
            "lets dive deeper.",
            "here's what you should know.",
            "let's explore that a bit."
        };
        public string InterestExtra() // method to passwords extra questions 
        {
            Random random = new Random();
            int index = random.Next(extraInterest.Count);
            return extraInterest[index];

        }
    }
}
   

    
  

