﻿using System;
using System.Collections.Generic;
namespace testing_assignment_1
{
    public class RandomResponses
    {


        private List<string> PhishingTips = new List<string>
      { "\nRecognize phishing signs. The attacker will send emails and messages that expresses urgency such as 'Your account will be closed or You have 24 hours to change your password'.",
        "\nLook out for spelling and grammar mistakes in emails or messages.",
        "\nEmails or message don't address you by your name instead they address you as dear customer.", "Do not click on links or emails from an unknown source or email address. Verify the email address by checking for misspellings, because official emails contains domain names such as @bank.com, instead of @gmail.com.",
        "\nProtect your information, never share your personal information such as passwords and credit cards via email. Enable (2FA) two-factor authentication to protect your account, as well as use strong passwords that are unique for different accounts."
        };
        public string GetRandomPhishingTip()
        {

            Random random = new Random();
            int index = random.Next(PhishingTips.Count);
            return PhishingTips[index];
        } }

   
    public class ElaboratePhishing
    {
        private List<string> PhishingDetails = new List<string> // extra details to phishing
      { "\nAttackers disguise themselves as trusted as trustworthy services such as banks and popular companies to steal your personal information using SMS, messages, emails and phone calls.",
        "\nPhishing is when attackers research the victim, this means they gather information on you to create realistic messages that's from a company or brand. They spoof emails and mimics professional communication.",
        "\nWith phishing attackers send links, attachments and expresses urgency in emails or messages. Links that lead you to a log in page that make you give out your log in information of you not carful. They link attachments to emails and messages that downloads malware onto your device and will send fake urgency messages to reset your password",
        "\nIf you experience this is most likely to occur. When you click on a link and any form of phishing attacks, your personal information such as credentials will get stolen, malware will be installed and financial fraud could occur."
        };
        public string GetRandomPhishingDetails()// method to phising details
        {

            Random random = new Random();
            int index = random.Next(PhishingDetails.Count);
            return PhishingDetails[index];
        }
    }
        public class PhishingInfo
    {
        public void PhishingIn()// gives general details on phishing
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\nPhishing is a cyber attack, It is used by impersonating as an organization, services or individuals to deceive users and gain sensitive information");
            
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("examples are:");
            Console.WriteLine("Email - Links or downloads are sent via email, with the attacker disguised as a legitimate company");
            Console.WriteLine("pressing on these links can cause you to be redirected to risky websites or have malicious malware installed on youur device");
            Console.WriteLine("Smishing - SMS phishing where malicious links and websites are sent via text messages");
            Console.WriteLine("Exit: to Quit");
            Console.WriteLine("Return: Return to previous questions");
            Console.ResetColor();
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");

        }
    }

}
